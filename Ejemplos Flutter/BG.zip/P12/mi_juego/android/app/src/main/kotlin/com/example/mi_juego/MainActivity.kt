package com.example.mi_juego

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
